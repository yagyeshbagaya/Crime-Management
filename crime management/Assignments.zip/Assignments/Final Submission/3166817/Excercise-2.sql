--EXERCISE 2

--Using JOINS

SELECT sc.CustomerID,sc.PersonID,sc.StoreID,sc.TerritoryID,sc.AccountNumber,sc.rowguid,sc.ModifiedDate
FROM Sales.Customer sc LEFT JOIN Sales.SalesOrderHeader soh
ON sc.CustomerID=soh.CustomerID 
WHERE soh.CustomerID IS NULL;


--Using SUB QUERY

SELECT  *
FROM Sales.Customer
WHERE CustomerID NOT IN 
           (SELECT soh.CustomerID from Sales.SalesOrderHeader soh );


--Using EXISTS

SELECT * FROM Sales.Customer as sc
WHERE NOT EXISTS (SELECT * FROM Sales.SalesOrderHeader as soh WHERE sc.CustomerID = soh.CustomerID);


--Using CTE

WITH Not_Placed_Order  
AS   
(  
    SELECT CustomerID, PersonID, StoreID, TerritoryID, AccountNumber, rowguid, ModifiedDate  
    FROM Sales.Customer
    WHERE CustomerID NOT IN (SELECT CustomerID FROM Sales.SalesOrderHeader )
)    
SELECT CustomerID, PersonID, StoreID, TerritoryID, AccountNumber, rowguid, ModifiedDate 
FROM Not_Placed_Order;