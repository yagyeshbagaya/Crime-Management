
Create Function Sales.getProduct(@SalesOrderID int, @CurrencyCode nchar(3), @CurrencyRateDate datetime)
RETURNS @Table Table( ProductID int, OrderQty int, UnitPrice int , ConvertedPrice int)
As
BEGIN
     Insert INTO @Table
	 Select sod.ProductID,
	 sod.OrderQty,

	 sod.UnitPrice,
	 
	 scr.EndOfDayRate * sod.UnitPrice AS 'Converted Price'
	 
	 From Sales.SalesOrderHeader AS soh
	 
	 INNER JOIN Sales.CurrencyRate AS scr
	 
	 ON soh.CurrencyRateID= scr.CurrencyRateID
	 
	 INNER JOIN Sales.SalesOrderDetail AS sod 
	 
	 ON soh.SalesOrderID= sod.SalesOrderID
	 
	 where sod.SalesOrderID= @SalesOrderID
	 
	 AND scr.ToCurrencyCode= @CurrencyCode
	 
	 AND scr.CurrencyRateDate= @CurrencyRateDate
	 
	 Return
End

Go
Select * from Sales.getProduct(43661,'CAD','2005-07-01 00:00:00.000')

---Drop the function if exist
 
 DROP FUNCTION IF EXISTS Sales.getProduct;

    