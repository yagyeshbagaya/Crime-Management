select top 5 SalesOrderNumber, PurchaseOrderNumber, AccountNumber
from AdventureWorks2008R2.Sales.SalesOrderHeader
where TotalDue > 70000 order by OrderDate desc
