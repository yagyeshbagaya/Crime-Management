select FirstName,LastName from AdventureWorks2008R2.Person.Person 
Join
    AdventureWorks2008R2.HumanResources.Employee 
on  
AdventureWorks2008R2.Person.Person.BusinessEntityID= AdventureWorks2008R2.HumanResources.Employee.BusinessEntityID
where  JobTitle IN('Design Engineer' ,'Tool Engineer' , 'Marketing Assistant')
