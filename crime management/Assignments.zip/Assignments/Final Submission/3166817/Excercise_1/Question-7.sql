select  ROW_NUMBER()
OVER
(
order by FirstName
)
AS Sequential ,FirstName,LastName from  AdventureWorks2008R2.Person.Person where FirstName like'%ss%'