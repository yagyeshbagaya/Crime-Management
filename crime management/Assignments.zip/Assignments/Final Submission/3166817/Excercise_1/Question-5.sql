 select Description , cast(isNULL(MaxQty,0.00) As numeric (10,2)) 
from AdventureWorks2008R2.Sales.SpecialOffer
