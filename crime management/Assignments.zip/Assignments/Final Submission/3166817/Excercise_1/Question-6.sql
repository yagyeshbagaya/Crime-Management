select avg(AverageRate) from AdventureWorks2008R2.Sales.CurrencyRate 
Where FromCurrencyCode='USD' and ToCurrencyCode='GBP' And Year(CurrencyRateDate)=2005
