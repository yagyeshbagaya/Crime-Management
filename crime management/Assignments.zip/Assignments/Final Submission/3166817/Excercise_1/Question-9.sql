Select Person.Person.BusinessEntityID , Person.Person.FirstName, Person.Person.MiddleName,
Person.Person.LastName, HumanResources.EmployeePayHistory.Rate,         
HumanResources.Employee.OrganizationLevel, HumanResources.Employee.JobTitle
FROM     
HumanResources.Employee 
INNER JOIN
HumanResources.EmployeePayHistory ON HumanResources.Employee.BusinessEntityID = HumanResources.EmployeePayHistory.BusinessEntityID
INNER JOIN
Person.Person ON HumanResources.Employee.BusinessEntityID = Person.Person.BusinessEntityID 
where Person.person.BusinessEntityID<49
order by Person.person.BusinessEntityID asc;
