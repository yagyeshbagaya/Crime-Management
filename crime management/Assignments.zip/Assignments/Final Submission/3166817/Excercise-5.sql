

CREATE PROCEDURE dbo.GetNames @Name nvarchar(30)=NULL
AS
SELECT * 
FROM Person.Person
WHERE FirstName = ISNULL(@Name,FirstName)


Go
EXEC dbo.GetNames @Name = 'Rob'

--- Whithout passing any value

Go
EXEC dbo.GetNames

---Drop the procedure if exist
Drop PROCEDURE if EXISTS dbo.GetNames
