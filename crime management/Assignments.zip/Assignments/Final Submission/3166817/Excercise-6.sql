
---Create the trigger

Create TRIGGER ensure ON Production.Product
 FOR INSERT 
AS 
IF EXISTS 
( SELECT * FROM inserted i JOIN deleted d ON i.ProductID = d.ProductID WHERE i.ListPrice > (d.ListPrice * 1.15)
 ) 
BEGIN RAISERROR('Price increase may not be greater than 15 percent. Transaction Failed.',16,1) 
ROLLBACK TRAN
 END 
GO 


---Alter the trigger



ALTER TRIGGER Production.ensure ON Production.Product
 FOR UPDATE
 AS 
IF EXISTS
 ( SELECT * FROM inserted i JOIN deleted d ON i.ProductID = d.ProductID WHERE i.ListPrice > (d.ListPrice * 1.15)
 ) 
BEGIN
 RAISERROR('Price increase may not be greater than 15 percent. Transaction Failed.',16,1) 
ROLLBACK TRAN
 END
 GO


---Checking by running the update command

 UPDATE Production.Product SET ListPrice=750 WHERE ProductID=723;