function addinfo() {
    var darr = [];
    var gender = "Male";
    var array = []
    var checkboxes = document.querySelectorAll('input[type=checkbox]:checked');
    for (var i = 0; i < checkboxes.length; i++) {
        array.push(checkboxes[i].value)
    }
    if (StudentRegistration.sex[1].checked == true) gender = "Female";
    var data = {
        name: document.getElementById("textname").value,
        email: document.getElementById("emailid").value,
        website: document.getElementById("web").value,
        img: document.getElementById("imglink").value,
        gender: gender,
        skills: array
    };
    if (data.name != "" && data.email != "" && data.img != "") 
    {
            darr.push(data);
            var row = tab.insertRow(1);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.style.borderBottom="2px solid";
            cell2.style.borderBottom="2px solid";
            cell2.style.borderTop="2px solid ";
            cell1.style.borderRight="2px solid ";
            cell2.style.borderLeft="2px solid ";
            cell2.style.width='20%';
            var link=darr[0].website.link(darr[0].website);
            var temp = darr[0].name.bold() +"</br>"+darr[0].gender + "</br>" + darr[0].email + "</br>" +link + "</br>" + darr[0].skills;
            cell1.innerHTML = temp;
            var val = darr[0].img;
            var img = document.createElement('img');
            img.src = val;
            img.style.width = '100px';
            img.style.height = '100px';
            cell2.appendChild(img);
            localStorage.clear();            
    }
}


function clearData() {
    localStorage.clear();
    window.location.reload(true);
}


