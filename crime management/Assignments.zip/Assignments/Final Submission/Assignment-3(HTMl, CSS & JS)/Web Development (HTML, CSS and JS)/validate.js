function validate() {
    if (document.StudentRegistration.textnames.value == "") {
        alert("Please provide your Name!");
        return false;
    }

    var email = document.StudentRegistration.emailid.value;
    var atpos = email.indexOf("@");
    var dotpos = email.lastIndexOf(".");
    if (email == "" || atpos < 1 || (dotpos - atpos < 2)) {
        alert("Please enter correct email ID");
        return false;
    }

    if ((StudentRegistration.sex[0].checked == false) && (StudentRegistration.sex[1].checked == false)) {
        alert("Please choose your Gender: Male or Female");
        return false;
    }

    var uurr = document.StudentRegistration.web.value;
    if (uurr == "") {
        alert("Website is mandatory");
    }
    else {
        return false;
    }

    var img = document.StudentRegistration.imglink.value;
    if (img == "") {
        alert("Image link must not be null");
        return false;
    }
    else {
        return false;
    }

    var chkBox = document.getElementsByName("skills[]");
    var lenChkBox = chkBox.length;
    var counter = 0;
    for (var i = 0; i < lenChkBox; i++) {
        if (chkBox[i].checked == true) {
            counter = 1;
            break;
        }
    }
    if (counter == 0) {
        alert("Please select atleast one skill");
        return false;
    }
    if (document.getElementById("java").checked == false && document.getElementById("html").checked == false && document.getElementById("css").checked == false) {
        alert('Please check at least one of the options.');
        return false;
    }
    return (true);
}


