package com.nagarro.inputoutput;
import java.util.*;
import java.util.Scanner;

class listOfItems {
	String resultName;
	Double resultPrice;
	Double resultTax;
	Double resultFinalPrice;
	listOfItems(String resultName, Double resultPrice, Double resultTax, Double resultFinalPrice) {
		this.resultName = resultName;
		this.resultPrice = resultPrice;
		this.resultTax = resultTax;
		this.resultFinalPrice = resultFinalPrice;
	}
}
public class IO {
	static List<listOfItems> List = new ArrayList<>();
	static double tax;
	enum items {
		Raw, Manufactured, Imported
	};
	static int count = 1;
	public static int input() {
		Scanner sc = new Scanner(System.in);
		try {
			String name;
			String type;
			double price;
			boolean flag = true;
			while (flag) {

				double totalPrice = 0.00;
				System.out.println("Enter  Name of the " + count + ". item");
				name = sc.nextLine();
				System.out.println("Enter  Price of the " + count + ".  item");
				price = sc.nextDouble();
				sc.nextLine();
				System.out.println("Enter  Qyantity of the " + count + ".  item");
				int quantity = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter  Type of the " + count + ".  item : Raw/Manufactured/Imported	");
				type = sc.nextLine();
				String choice;
				items item = items.valueOf(type);
				switch (item) {
				case Raw:
					totalPrice = calculateRawType(quantity, price);
					break;

				case Manufactured:
					totalPrice = calculateManufacturedType(quantity, price);
					break;
				case Imported:
					totalPrice = calculateImportedType(quantity, price);
					break;
				}
				listOfItems object = new listOfItems(name, price, tax, totalPrice);
				List.add(object);
				System.out.print("Do you want to enter details of any other item (y/n):");
				choice = sc.nextLine();
				System.out.println();
				System.out.println();
				System.out.println();
				if ("n".equalsIgnoreCase(choice)) {
					flag = false;
				} else if ("y".equalsIgnoreCase(choice)) {
					count++;
				}
			}
		} catch (Exception sk) {
			System.out.println(sk);
		}
		sc.close();
		return 1;
	}

	public static double calculateRawType(int quantity, double price) {
		tax = (12.5 * price) / 100;
		return quantity * price + (tax) * quantity;
	}

	public static double calculateManufacturedType(int quantity, double price) {
		tax = (0.125 * price) + (0.02 * (price + (0.125 * price)));
		return quantity * price + (tax) * quantity;
	}

	public static double calculateImportedType(int quantity, double price) {
		tax = (10 * price) / 100;
		double totalPrice = price + tax;
		if (totalPrice < 100) {
			tax = tax + 5;
			totalPrice = (totalPrice + 5) * quantity;
		} else if (totalPrice >= 100 && totalPrice < 200) {
			tax = tax + 10;
			totalPrice = (totalPrice * 10) * quantity;
		} else if (totalPrice > 200) {
			tax = tax + (5 * totalPrice) / 100;
			totalPrice = (totalPrice + (0.05 * totalPrice)) * quantity;
		}
		return totalPrice;
	}

	public static void output() {
		try {
			String Line = "------------------------------------------------------------------------------------------------------------------";
			for (int i = 0; i < List.size(); i++) {
				listOfItems object = List.get(i);
				System.out.println(Line);
				System.out.println("The Details of Item " + (i + 1) + ". are  ");
				System.out.println(Line);
				System.out.println("The Name of an item is :                " + object.resultName + "           ");
				System.out
						.println("The  Price of an item is :              Rs" + object.resultPrice + "\\-            ");
				System.out.println("The Sales Tax per item is :             Rs" + object.resultTax + "\\-          ");
				System.out.println("The Final Price of an item  is :        Rs" + object.resultFinalPrice + "\\-    ");
				System.out.println(Line);
				System.out.println();
				System.out.println();
			}
		} catch (Exception sk) {
			System.out.println(sk);
		}
	}
}
