package com.nagarro.assignment1;
import com.nagarro.inputoutput.*;
public class ItemDetails {
	public static void main(String [] args )
	{
		int result = IO.input();
		if (result == 1)
			IO.output();
	}

}
