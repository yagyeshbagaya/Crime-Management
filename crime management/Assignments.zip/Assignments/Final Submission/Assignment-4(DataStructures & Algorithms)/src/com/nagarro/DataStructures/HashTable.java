package com.nagarro.DataStructures;

public class HashTable<S, T> {
	public static class Node<S, T> {
		S key;
		T data;
		Node<S, T> next;

		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}
	public Comparator<S> comp;
	public HashTable(Comparator<S> comp) {
		this.comp = comp;
	}
	private Node<S, T> head = null;
	static int count = 0;
	public void insert(S key, T data) {
		Node<S, T> newNode = new Node<S, T>(data);
		if (head == null) {
			head = newNode;
			newNode.data = data;
			newNode.key = key;
			newNode.next = null;
		} else {
			if (comp.compare(head.key, key)) {
				newNode.next = head;
				head = newNode;
				newNode.data = data;
				newNode.key = key;
			} else {
				Node<S, T> temp = head;
				Node<S, T> temp1 = temp;
				while (temp != null) {
					if (temp.key == key) {
						temp.data = data;
						return;
					}
					if (comp.compare(temp.key, key)) {
						temp1.next = newNode;
						newNode.data = data;
						newNode.key = key;
						newNode.next = temp;
						return;
					}
					temp1 = temp;
					temp = temp.next;
				}
				temp1.next = newNode;
				newNode.data = data;
				newNode.key = key;
				newNode.next = null;
			}
		}
	}
	public void delete(S key) {
		Node<S, T> temp = head;
		Node<S, T> temp1 = temp;
		if (head == null) {
			System.out.println("Hash Table is empty");
			return;
		}
		if (head.key == key) {
			head = head.next;
			System.out.println("deletion is empty");
			return;
		}
		while (temp != null) {
			if (temp.key == key) {
				temp1.next = temp.next;
				System.out.println("Deletion is done");
				return;
			}

			temp1 = temp;
			temp = temp.next;
		}
		temp1.next = null;
		System.out.println("Deletion is done");
	}
	public int size() {
		int size = 0;
		Node<S, T> temp = head;
		while (temp != null) {
			temp = temp.next;
			size++;
		}
		return size;
	}

	public void show() {
		Node<S, T> temp = head;
		if (temp == null) {
			System.out.println("HashTable is empty");
			return;
		}
		while (temp != null) {
			System.out.println("   The key is : " + temp.key + "   The data is   " + temp.data);
			temp = temp.next;
		}
	}

	public boolean contains(T data) {
		Node<S, T> temp = head;
		if (temp == null) {
			System.out.println("HashTable is empty");
			return false;
		} else {
			while (temp != null) {
				if (temp.data == data)
					return true;
				temp = temp.next;
			}
		}
		return false;
	}

	public T getValue(S key) {
		int flag = 0;
		Node<S, T> temp = head;
		while (temp != null) {
			if (temp.key == key) {
				flag = 1;
				break;
			}

			temp = temp.next;
		}
		if (flag == 1)
			return temp.data;
		else
			return null;
	}

	public HashTableIterator<S, T> iterator() {
		return new HashTableIterator<S, T>(head);
	}
}
