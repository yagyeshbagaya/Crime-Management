package com.nagarro.DataStructures;
public class HashTableIterator<S, T> implements Iterator<S> {
	public HashTableIterator(HashTable.Node<S, T> head) {
		this.current = head;
	}
	HashTable.Node<S, T> current;
	public boolean hasNext() {
		return current != null;

	}
	public S next() {
		if (current == null)
			return null;
		S data = current.key;
		current = current.next;
		return data;
	}
}
