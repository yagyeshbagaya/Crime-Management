package com.nagarro.assignment;
import com.nagarro.DataStructures.*;
public class Comparable<T> implements Comparator<T> {
	public boolean compare(T a, T b) {
		int x = (int) a;
		int y = (int) b;
		if (x < y) {
			return true;
		}
		return false;
	}
	public int comparre(T a, T b) {
		int x = (int) a;
		int y = (int) b;
		if (x == y)
			return 0;
		else if (x < y)
			return -1;
		else
			return 1;
	}
}
