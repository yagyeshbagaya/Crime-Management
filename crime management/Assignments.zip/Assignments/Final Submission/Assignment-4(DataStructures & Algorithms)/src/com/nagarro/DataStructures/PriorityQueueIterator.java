package com.nagarro.DataStructures;
public class PriorityQueueIterator <T> implements Iterator <T>
{
	public PriorityQueueIterator(PriorityQueue.Node <T> head)
	{
		this.current=head;		
	}
	PriorityQueue.Node <T> current;
	public boolean hasNext()
	{
		return current!=null;
			}
	public T next()
	{	
		if(current==null)
			return null;
		T data=current.data;
		current=current.next;
		return data;
		}
}
