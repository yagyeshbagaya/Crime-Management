package com.nagarro.DataStructures;
public class StackIterator <T> implements Iterator <T>{	
	public StackIterator(Stack.Node <T> head)
	{
		this.current=head;		
	}	
	Stack.Node <T> current;
	public boolean hasNext()
	{
		return current!=null;	
			}
	public T next()
	{	
		if(current==null)
			return null;
		T data=current.data;
		current=current.next;
		return data;
		}
}
