package com.nagarro.DataStructures;
public class Queue <T> 
{
	public static class Node<T> {
		T data;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}
	private Node<T> head = null;
	private Node<T> tail = null;
	public void enqueue(T data)
	{
	Node<T> newNode = new Node<T> (data);
	if(head==null && tail==null)
	{
		head=newNode;
		tail=newNode;
	    newNode.next=null;
	}
	else
	{
		tail.next=newNode;
		tail=newNode;
		newNode.next = null;		
	}
}
	
	public T dequeue() {
		T data=head.data;	
		head=head.next;
		if(head==null)
			tail=null;			
	     return data;
	}

	public int size() {
		int size = 0;
		Node<T> temp = head;
		while (temp != null) {
			temp = temp.next;
			size++;
		}
		return size;		
	}	
	
	public void reverseQueue() 
	{
		Node <T> temp=head;
		Node <T> temp1=temp;
		Node <T> root=null;
		tail=head;
		while(temp!=null)
		{
			temp1=temp;
			temp=temp.next;
			temp1.next=root;
			root=temp1;
		}
		head=temp1;
	}
	public QueueIterator <T> iterator()
	{
		return new QueueIterator <T> (head);
	}	
	public boolean contains(T data) {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("Stack is empty");
			return false;
		}
		while (temp != null) {
           if(temp.data==data)
        	   return true;			
			temp = temp.next;
		}
		return false;
	}

	public void show() {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("Linked List is empty");
			return;		
			}
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
	}
	
	public void peek() 
	{
	System.out.println("The front element of Queue is"+head.data);	
	}
	
	public boolean isEmpty()
	{
		if(head==null)
			return true;
		else
			return false;
	}
	public void clear()
	{
		head=null;
		tail=null;
	}
}
