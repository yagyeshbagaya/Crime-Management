package com.nagarro.assignment;
import com.nagarro.DataStructures.*;
import java.util.Scanner;
public class Main {
	enum Data {
		LinkedList, Stack, Queue, PriorityQueue, NChildTree, HashTable
	};
	static Scanner sc;
	static Iterator<Integer> iterate;
	static Comparable<Integer> comp;
	public static void main(String[] args) {
		try {
			sc = new Scanner(System.in);
			boolean flag = true;
			while (flag) {
				System.out.println("Enter the data structure:\n" + "LinkedList  " + "\n" + "Stack\n" + "Queue\n"
						+ "PriorityQueue\n" + "NChildTree\n" + "HashTable");
				System.out.println(
						"***************************************************************************************");
				String type = sc.next();
				Data dt = Data.valueOf(type);
				switch (dt) {
				case LinkedList:
					linkedListChoice();
					break;
				case Stack:
					stackChoice();
					break;
				case Queue:
					queueChoice();
					break;
				case PriorityQueue:
					priorityQueueChoice();
					break;
				case NChildTree:
					nChildTreeChoice();
					break;
				case HashTable:
					hashTableChoice();
					break;
				}
			}
			sc.close();
		} catch (Exception sk) {
			System.out.println(sk.toString());
		}
		}
	public static void linkedListChoice() {
		boolean flag1 = true;
		int data;
		LinkedList<Integer> lst = new LinkedList<>();
		while (flag1) {
			System.out.println("Press 1. for adding the node");
			System.out.println("Press 2. for inserting node at the position");
			System.out.println("Press 3. for deleting the node");
			System.out.println("Press 4. for displaying the node");
			System.out.println("Press 5. for displaying center node");
			System.out.println("Press 6. for deleting the node from the position");
			System.out.println("Press 7. for reverse the list");
			System.out.println("Press 8. for displaying elements through Iterator");
			System.out.println("Press 9. for choosing the datastructure");
			System.out.println("Press 10. for exit");
			System.out
					.println("***************************************************************************************");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the data :");
				data = sc.nextInt();
				lst.addNode(data);
				System.out.println("Data inserted");
				break;
			case 2:
				System.out.println("Enter the data :");
				data = sc.nextInt();
				System.out.println("Enter the Position :");
				int position = sc.nextInt();
				lst.insertAtPosition(position, data);
				System.out.println("Data inserted");
				break;
			case 3:
				lst.remove();
				break;
			case 4:
				System.out.println(" The elements are :");
				lst.show();
				break;
			case 5:
				System.out.println("The element at center is  :");
				lst.elementAtCenter();
				break;
			case 6:
				System.out.println("Enter the Position to be deleted :");
				int pos = sc.nextInt();
				lst.deleteAtPosition(pos);
				System.out.println("Data deleted ");
				break;
			case 7:
				System.out.println("The list is reversed :");
				lst.reverseList();
				break;
			case 8:
				System.out.println("The elements are :");
				iterate = lst.iterator();
				while (iterate.hasNext()) {
					System.out.println(iterate.next());
				}
				break;
			case 9:
				flag1 = false;
				break;
			case 10:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}

	public static void stackChoice() {
		Stack<Integer> stk = new Stack<Integer>();
		int data;
		boolean flag1 = true;
		while (flag1) {
			System.out.println("Press 1. for performing push operation");
			System.out.println("Press 2. for performing peek operation");
			System.out.println("Press 3. for performing pop operation");
			System.out.println("Press 4. for print the elements");
			System.out.println("Press 5. for checking whether element contains in the stack ");
			System.out.println("Press 6. for the size of the stack");
			System.out.println("Press 7. for reversing the stack");
			System.out.println("Press 8. for displaying elements through Iterator");
			System.out.println("Press 9. for choosing the datastructure");
			System.out.println("Press 10.for exit");
			System.out
					.println("***************************************************************************************");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				stk.push(data);
				System.out.println("Data Pushed");
				break;
			case 2:
				stk.peek();
				break;
			case 3:
				System.out.println("Data Poped : " + stk.pop());
				break;
			case 4:
				System.out.println("The elements are : ");
				stk.show();
				break;
			case 5:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				System.out.println(stk.contains(data));
				break;
			case 6:
				System.out.println("The size of stack is  " + stk.size());
				break;
			case 7:
				System.out.println("Stack reversed ");
				stk.reverseStack();
				break;
			case 8:
				iterate = stk.iterator();
				while (iterate.hasNext()) {
					System.out.println(iterate.next());
				}
				break;
			case 9:
				flag1 = false;
				break;

			case 10:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}

	public static void queueChoice() {
		Queue<Integer> queue = new Queue<Integer>();
		int data;
		boolean flag1 = true;
		while (flag1) {
			System.out.println("Press 1. for performing enqueue operation");
			System.out.println("Press 2. for performing peek operation");
			System.out.println("Press 3. for performing dequeue operation");
			System.out.println("Press 4. for print the elements");
			System.out.println("Press 5. for checking whether element contains in the Queue ");
			System.out.println("Press 6. for the size of the Queue");
			System.out.println("Press 7. for reversing the Queue");
			System.out.println("Press 8. for displaying elements through Iterator");
			System.out.println("Press 9. for choosing the datastructure");
			System.out.println("Press 10.for exit");
			System.out
					.println("***************************************************************************************");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				queue.enqueue(data);
				break;
			case 2:
				queue.peek();
				break;
			case 3:
				System.out.println("Dequeue done : " + queue.dequeue());
				break;
			case 4:
				System.out.println("The elements are : ");
				queue.show();
				break;
			case 5:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				System.out.println(queue.contains(data));
				break;
			case 6:
				System.out.println("The size of queue is  " + queue.size());
				break;
			case 7:
				System.out.println("Queue reversed ");
				queue.reverseQueue();
				break;
			case 8:
				iterate = queue.iterator();
				while (iterate.hasNext()) {
					System.out.println(iterate.next());
				}
				break;
			case 9:
				flag1 = false;
				break;

			case 10:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}

	public static void priorityQueueChoice() {
		comp = new Comparable<Integer>();
		PriorityQueue<Integer> priorityqueue = new PriorityQueue<Integer>(comp);
		int data;
		boolean flag1 = true;
		while (flag1) {
			System.out.println("Press 1. for performing enqueue operation");
			System.out.println("Press 2. for performing peek operation");
			System.out.println("Press 3. for performing dequeue operation");
			System.out.println("Press 4. for print the elements");
			System.out.println("Press 5. for checking whether element contains in the PriorityQueue ");
			System.out.println("Press 6. for the size of the PriorityQueue");
			System.out.println("Press 7. for reversing the PriorityQueue");
			System.out.println("Press 8. for displaying elements through Iterator");
			System.out.println("Press 9. for choosing the datastructure");
			System.out.println("Press 10.for exit");
			System.out
					.println("***************************************************************************************");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				priorityqueue.enqueue(data);
				System.out.println("Enqueue Done ");
				break;
			case 2:
				priorityqueue.peek();
				break;
			case 3:
				System.out.println("Dequeue done : " + priorityqueue.dequeue());
				break;
			case 4:
				System.out.println("The elements are : ");
				priorityqueue.show();
				break;
			case 5:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				System.out.println(priorityqueue.contains(data));
				break;
			case 6:
				System.out.println("The size of priorityqueue is  " + priorityqueue.size());
				break;
			case 7:
				System.out.println("PriorityQueue reversed ");
				priorityqueue.reversePriorityQueue();
				break;
			case 8:
				iterate = priorityqueue.iterator();
				while (iterate.hasNext()) {
					System.out.println(iterate.next());
				}
				break;
			case 9:
				flag1 = false;
				break;

			case 10:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}

	public static void hashTableChoice() {
		comp = new Comparable<Integer>();
		HashTable<Integer, String> hashtable = new HashTable<Integer, String>(comp);
		String data;
		int key;
		boolean flag1 = true;
		while (flag1) {
			System.out.println("Press 1. for performing insert operation");
			System.out.println("Press 2. for performing delete operation");
			System.out.println("Press 3. for print the elements");
			System.out.println("Press 4. for checking whether element contains in the HashTable ");
			System.out.println("Press 5. for the size of the HashTable");
			System.out.println("Press 6. for getting value by key ");
			System.out.println("Press 7. for displaying elements through Iterator");
			System.out.println("Press 8. for choosing the datastructure");
			System.out.println("Press 9.for exit");
			System.out
					.println("***************************************************************************************");

			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the key ");
				key = sc.nextInt();
				System.out.println("Enter the data ");
				data = sc.next();
				hashtable.insert(key, data);
				System.out.println("data  inserted");
				break;
			case 2:
				System.out.println("Enter the key ");
				key = sc.nextInt();
				hashtable.delete(key);
				break;
			case 3:
				System.out.println("The elements are : ");
				hashtable.show();
				break;
			case 4:
				System.out.println("Enter the data ");
				data = sc.next();
				System.out.println(hashtable.contains(data));
				break;
			case 5:
				System.out.println("The size of hashtable is  " + hashtable.size());
				break;
			case 6:
				System.out.println("Enter the key : ");
				key = sc.nextInt();
				System.out.println("The value  is  " + hashtable.getValue(key));
				break;

			case 7:
				iterate = hashtable.iterator();
				while (iterate.hasNext()) {
					int dat = iterate.next();
					System.out.println("The key is :  " + dat + "   The value is :  " + hashtable.getValue(dat));
				}
				break;
			case 8:
				flag1 = false;
				break;

			case 9:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}

	public static void nChildTreeChoice() {
		int data;
		System.out.println("Enter the number of child for NChildTree  ");
		data = sc.nextInt();
		NChildTree<Integer> nChild = new NChildTree<Integer>(data);
		boolean flag1 = true;
		while (flag1) {
			System.out.println("Press 1. for performing insert operation");
			System.out.println("Press 2. for performing delete operation");
			System.out.println("Press 3. for printing elements by level ");
			System.out.println("Press 4. for printing BFS  ");
			System.out.println("Press 5. for printing DFS  ");
			System.out.println("Press 6. for choosing the datastructure");
			System.out.println("Press 7.for exit");
			System.out
					.println("***************************************************************************************");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter the data ");
				data = sc.nextInt();
				nChild.insert(data);
				System.out.println("data inserted");
				break;
			case 2:
				comp = new Comparable<>();
				System.out.println("Enter the data to be deleted : ");
				data = sc.nextInt();
				nChild.delete(data, comp);
				break;
			case 3:
				System.out.println("Enter the level : ");
				data = sc.nextInt();
				nChild.getElementsByLevel(data);
				break;
			case 4:
				System.out.println("The BFS traversal of tree is : ");
				iterate = nChild.iteratorBFS();
				while (iterate.hasNext()) {
					System.out.println( iterate.next());
				}
				break;
			case 5:
				System.out.println("The DFS traversal of tree is : ");
				iterate = nChild.iteratorDFS();
				while (iterate.hasNext()) {
					System.out.println(iterate.next());
				}
				break;
			case 6:
				flag1 = false;
				break;
			case 7:
				System.exit(0);
			}
			System.out
					.println("***************************************************************************************");
		}
	}
}
