package com.nagarro.DataStructures;
public class NChildTree<T> {
	static class Node<T> {
		T data;
		Node<T> firstChild;
		Node<T> nextSibling;
		int childCount;
		Node(T data) {
			this.data = data;
			this.firstChild = null;
			this.nextSibling = null;
			this.childCount = 0;
		}
	}
	int size;
	Node<T> root;
	Queue<Node<T>> queue = new Queue<Node<T>>();
	public NChildTree(int size) {
		this.size = size;
	}
	public NChildTreeIteratorBFS<T> iteratorBFS() {
		return new NChildTreeIteratorBFS<T>(root);
	}

	public NChildTreeIteratorDFS<T> iteratorDFS() {
		return new NChildTreeIteratorDFS<T>(root);
	}
	public void insert(T data) {
		Queue<Node<T>> queue = new Queue<>();
		Node<T> newNode = new Node<T>(data);
		if (root != null)
			queue.enqueue(root);
		else
			root = newNode;
		Node<T> current;
		while (!queue.isEmpty()) {
			current = queue.dequeue();
			if (current.childCount < size) {
				if (current.firstChild == null) {
					current.childCount++;
					current.firstChild = newNode;
				} else {
					current.childCount++;
					current = current.firstChild;
					while (current.nextSibling != null) {
						current = current.nextSibling;
					}
					current.nextSibling = newNode;
				}
				queue.clear();
				break;
			}
     		current = current.firstChild;
			while (current != null) {
				queue.enqueue(current);
				current = current.nextSibling;
			}
		}
	}

	public void delete(T data, Comparator<T> comp) {
		Queue<Node<T>> queue = new Queue<>();
		if (root != null)
			queue.enqueue(root);
		Node<T> current, previous = null;
		while (!queue.isEmpty()) {
			current = queue.dequeue();
			if (comp.comparre(current.data, data) == 0) {
				// deletion starts here
				if (current.firstChild == null) {
					if (previous == null)
						root = null;
					else if (previous.firstChild == null) {
						previous.nextSibling = current.nextSibling;
					} else if (previous.nextSibling == null) {
						previous.firstChild = current.nextSibling;
					} else {
						String fc = previous.firstChild.toString();
						String c = current.toString();
						if (c.equals(fc))
							previous.firstChild = current.nextSibling;
						else
							previous.nextSibling = current.nextSibling;
					}
				} else {
					if (previous == null)
						root = current.firstChild;
					else {
						String fc = previous.firstChild.toString();
						String c = current.toString();
						if (c.equals(fc))
							previous.firstChild = current.firstChild;
						else
							previous.nextSibling = current.firstChild;
					}
				}
				Stack<Node<T>> s = new Stack<>();
				while (current.firstChild != null) {
					s.push(current);
					current = current.firstChild;
				}
				if (!s.isEmpty()) {
					Node<T> node = s.pop();
					current.firstChild = current.nextSibling;
					current.childCount = node.childCount - 1;
					current.nextSibling = node.nextSibling;
					current = node;
				}
				while (!s.isEmpty()) {
					Node<T> node = s.pop();
					current.childCount = node.childCount;
					current.nextSibling = node.nextSibling;
					current = node;
				}
				// deletion ends here
				break;
			}
			previous = current;
			current = current.firstChild;
			while (current != null) {
				queue.enqueue(current);
				current = current.nextSibling;
			}
		}
	}

	public void getElementsByLevel(int level) {
		Queue<Node<T>> queue = new Queue<>();
		if (root != null)
			queue.enqueue(root);
		int count = 1;
		while (!queue.isEmpty() && level > 0) {
			Node<T> node;
			int temp = 0;
			for (int e = 1; e <= count; e++) {
				node = queue.dequeue();
				temp += node.childCount;
				node = node.firstChild;
				while (node != null) {
					queue.enqueue(node);
					node = node.nextSibling;
				}
			}
			count = temp;
			level--;
		}
		LinkedList<T> list = new LinkedList<>();
		while (!queue.isEmpty()) {
			list.addNode(queue.dequeue().data);
		}
		list.show();
	}
}
