package com.nagarro.DataStructures;
public class PriorityQueue <T> 
{	public static class Node<T> {
		T data;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			this.next = null;
		}
		}
	public  Comparator <T> comp;
	public PriorityQueue (Comparator <T> comp)
	{
		this.comp=comp;		
	}
	private Node<T> head = null;
	static int count=0;
	public void enqueue(T data)
	{
	Node<T> newNode = new Node <T> (data);
	if(head==null)
	{
		head=newNode;
	    newNode.data=data;
	    newNode.next=null;
	}
	else
	{
		if(count%2==0)
		{
		if(comp.compare(data,head.data))
		{
			newNode.next=head;
			head=newNode;
		    newNode.data=data;
		}
		else
		{
			Node <T> temp=head;
			Node <T> temp1=temp;
		while(temp!=null)
		{
			if(comp.compare(data, temp.data))
			{
				temp1.next=newNode;
				newNode.data=data;
				newNode.next=temp;
				return;
			}
			temp1=temp;
			temp=temp.next;
		}
temp1.next=newNode;
newNode.data=data;
newNode.next=null;
		}
		}
		else
		{
			if(comp.compare(head.data,data))
			{
				newNode.next=head;
				head=newNode;
			    newNode.data=data;
			}
			else
			{
				Node <T> temp=head;
				Node <T> temp1=temp;
			while(temp!=null)
			{
				if(comp.compare(temp.data,data))
				{
					temp1.next=newNode;
					newNode.data=data;
					newNode.next=temp;
					return;
				}
				temp1=temp;
				temp=temp.next;
			}
	temp1.next=newNode;
	newNode.data=data;
	newNode.next=null;
			}				
		}	
	}	
	}

	public T dequeue() {		
		T data=head.data;	
		head=head.next;	
	     return data;
	}
	public int size() {
		int size = 0;
		Node<T> temp = head;
		while (temp != null) {
			temp = temp.next;
			size++;
		}
		return size;		
	}	
	public PriorityQueueIterator <T> iterator()
	{
		return new PriorityQueueIterator <T> (head);
	}
	public boolean contains(T data) {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("PriorityQueue is empty");
			return false;
		}
		while (temp != null) {
           if(temp.data==data)
        	   return true;			
			temp = temp.next;
		}
		return false;
	}
	public void show() {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("Priority Queue is empty");
			return;		
			}
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
	}	
	public void peek() 
	{
	System.out.println("The front element of Queue is :  "+head.data);	
	}
	public void reversePriorityQueue() 
	{
		count++;
		Node <T> temp=head;
		Node <T> temp1=temp;
		Node <T> root=null;	
		while(temp!=null)
		{
			temp1=temp;
			temp=temp.next;
			temp1.next=root;
			root=temp1;
		}
		head=temp1;
	}
}
