package com.nagarro.DataStructures;
public class NChildTreeIteratorBFS<T> implements Iterator<T> {
	Queue<NChildTree.Node<T>> queue = new Queue<>();
	public NChildTreeIteratorBFS(NChildTree.Node<T> root) {
		if (root != null)
			queue.enqueue(root);
	}
	public boolean hasNext() {
		return !queue.isEmpty();
	}
	public T next() {
		NChildTree.Node<T> current = queue.dequeue();
		T data = current.data;
		current = current.firstChild;
		while (current != null) {
			queue.enqueue(current);
			current = current.nextSibling;
		}
		return data;
	}
}
