package com.nagarro.DataStructures;

public class Stack<T>  {
public static class Node<T> {
		T data;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}
	private Node<T> head = null;
	Node <T> tempNext;
	Node <T> tempHasNext;
	public void push(T data)
	{
	Node<T> newNode = new Node<> (data);
		newNode.next = head;
		head = newNode;
		tempHasNext=head;
	}
	public T pop()
	{
	T data=head.data;
	head = head.next;
	tempHasNext=head;
	return data;
	}
	
	public void show() {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("Stack is empty");
			return;		
			}
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
	}
	public void peek() 
	{
	System.out.println("The top element in Stack is  "+head.data);	
	}	
	public int size() {
		int size = 0;
		Node<T> temp = head;
		while (temp != null) {
			temp = temp.next;
			size++;
		}
		return size;		
	}	
	public void reverseStack() 
	{
		Node <T> temp=head;
		Node <T> temp1=temp;
		Node <T> root=null;
		while(temp!=null)
		{
			temp1=temp;
			temp=temp.next;
			temp1.next=root;
			root=temp1;
		}
		    head=temp1;
	}
	public StackIterator <T> iterator()
	{
		return new StackIterator <> (head);
	}
	public boolean contains(T data) {
		Node<T> temp = head;
		if (temp == null) {
			System.out.println("Stack is empty");
			return false;
		}
		while (temp != null) {
           if(temp.data==data)
        	   return true;		
			temp = temp.next;
		}
		return false;
	}
	public boolean isEmpty()
	{
		if(head==null)
			return true;
		else
			return false;
	}
}
