package com.nagarro.DataStructures;
public class NChildTreeIteratorDFS <T> implements Iterator <T>
{
Stack <NChildTree.Node <T> > stack1=new Stack<>();
	public NChildTreeIteratorDFS(NChildTree.Node<T> root)
	{
		if(root!=null)	
		stack1.push(root);		
	}
	public boolean hasNext()
	{
		return !stack1.isEmpty();
		}
	public T next()
	{	
		Stack <NChildTree.Node <T> > stack2=new Stack<>();
		NChildTree.Node <T> current=stack1.pop();
	T data=current.data;
	current=current.firstChild;
	while(current!=null)
	{
	stack2.push(current);
	current=current.nextSibling;
	}
	while(!stack2.isEmpty())
	{
	stack1.push(stack2.pop());
	}
	return data;
	}
}