package com.nagarro.DataStructures;
import java.util.Objects;

public class LinkedList<T> {
	public static class Node<T> {
		T data;
		Node<T> next;
		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}
	private Node<T> head = null;
	private Node<T> tail = null;
	public void addNode(T data) {
		Node<T> newNode = new Node<>(data);
		if (head == null && tail == null) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			tail = newNode;
		}
		}

	public void show() {
		Node<T> temp = head;
		if (Objects.isNull(temp)) {
			System.out.println("Linked List is empty");
			return;
		}
		while (temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
	}

	public void remove() {
		Node<T> temp1 = head;
		Node<T> temp2 = temp1;
		if (temp1 == null) {
			System.out.println("Linked List is empty");
			return;
		}
		else if(temp1.next==null)
		{
			head=null;
		    return ;
		}
			while (temp1.next != null) {
			temp2 = temp1;
			temp1 = temp1.next;
		}
		tail = temp2;
		temp2.next = null;
	}

	public void insertAtPosition(int position, T data) {
		int count = 1;
		int size = listSize();
		if (size + 1 < position) {
			System.out.println("Please enter the correct position");
			return;
		}
		Node<T> newNode = new Node<>(data);
		if (position == 1) {
			newNode.next = head;
			head = newNode;
			return;
		}
		Node<T> temp = head;
		Node<T> temp1 = temp;
		while (temp != null) {
			if (count == position) {
				newNode.next = temp;
				temp1.next = newNode;
				break;
			}
			temp1 = temp;
			temp = temp.next;
			count++;
		}
		if (position == size + 1) {
			temp1.next = newNode;
			newNode.next = null;
			tail = newNode;
		}
	}
	public void deleteAtPosition(int position) {
		int count = 1;
		int size = listSize();
		if (position > size + 1) {
			System.out.println("Invalid Position");
			return;
		}
		if (position == 1) {
			head = head.next;
			return;
		}
		Node<T> temp = head;
		Node<T> temp1 = temp;
		while (temp != null) {
			if (count == position) {
				temp1.next = temp.next;
				return;
			}
			temp1 = temp;
			temp = temp.next;
			count++;
		}
		

	}
	public void elementAtCenter() {
		Node<T> fast = head;
		Node<T> slow = head;
		if (fast == null)
			System.out.println("List is empty");
		else {
			if (listSize() % 2 == 0) {
				while (fast != null) {
					fast = fast.next.next;
					slow = slow.next;
				}
				System.out.println("The center element is  " + slow.data);
			} else {
				while (fast.next != null) {
					fast = fast.next.next;
					slow = slow.next;
				}
				System.out.println("The center element is  " + slow.data);

			}
		}
	}
	public int listSize() {
		int size = 0;
		Node<T> temp = head;
		while (temp != null) {
			temp = temp.next;
			size++;
		}
		return size;

	}
	public void reverseList() {
		Node<T> temp = head;
		Node<T> temp1 = temp;
		Node<T> root = null;
		tail = head;
		while (temp != null) {
			temp1 = temp;
			temp = temp.next;
			temp1.next = root;
			root = temp1;
		}
		head = temp1;
	}

	public LinkedListIterator<T> iterator() {
		return new LinkedListIterator<>(head);
	}
}
