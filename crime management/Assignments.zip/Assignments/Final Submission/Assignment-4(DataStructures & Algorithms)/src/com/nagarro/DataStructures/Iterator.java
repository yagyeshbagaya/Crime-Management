package com.nagarro.DataStructures;
public interface Iterator<T> {
	public boolean hasNext();
	public T next();

}
