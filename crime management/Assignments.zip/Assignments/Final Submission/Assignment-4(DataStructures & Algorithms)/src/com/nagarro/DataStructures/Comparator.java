package com.nagarro.DataStructures;
public interface Comparator<T> {
	public boolean compare(T a, T b);

	public int comparre(T a, T b);

}
