package com.nagarro.assignment;
import java.text.SimpleDateFormat;
import java.util.*;
import com.nagarro.flightdetails.DAO;
import com.nagarro.flightdetails.Flight;
public class Main {
	public static void main(String gg[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		int choice=1;
	switch(choice)
			{
			case 1:
		System.out.println("Enter the departure location");
		String depLoc = sc.nextLine();
		System.out.println("Enter the arrival location");
		String arrLoc = sc.nextLine();
		System.out.println("Enter the date which is valid til");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		Date flightDate = sdf.parse(sc.nextLine());
		System.out.println("Enter the Flight Class");
		String classType = sc.nextLine();
		System.out.println("Enter the  Fare or Both (fare and flight duration) by which you have to filter");
		String outputPreference = sc.nextLine();
		 DAO fi = new DAO();
List<Flight> list = fi.getFlights(depLoc, arrLoc, flightDate, classType, outputPreference);
		Iterator<Flight> i = list.iterator();
		System.out.println();
		System.out.println("List of available flights : " + "\n");
		System.out.println("Id   " + "  Dep Loc " + " Arr Loc " + " Valid Till " + " Arrival Time " + " Duration "
				+ " Fare " + " Class Type ");
		while (i.hasNext()) {
			Flight f = i.next();
			System.out.println(f.getFlightNo() + "    " + f.getDepLoc() + "     " + f.getArrLoc() + "    "
					+ new SimpleDateFormat("dd-MMM-yyyy").format(f.getValidTill()) + "    "
					+ f.getFlightTime().substring(0, 2) + ":" + f.getFlightTime().substring(2) + "        "
					+ f.getFlightDur() + "     " + f.getFare() + "    " + f.getClassType());
		}
			break;
		case 2:
			sc.close();
		System.exit(0);		
			}

		
	}
}