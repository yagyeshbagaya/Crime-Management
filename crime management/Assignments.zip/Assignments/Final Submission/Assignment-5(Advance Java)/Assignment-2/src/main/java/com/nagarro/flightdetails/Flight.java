package com.nagarro.flightdetails;
import java.util.*;

import javax.persistence.*;
@Entity  
@Table(name= "flightsdetails")   
public class Flight {   
	@Id   
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String flightNo;
	private String depLoc;
	private String arrLoc;
	@Temporal(TemporalType.DATE)
	private Date validTill;
	private String flightTime;
	private String flighDur;
	private String fare;
	private String seatAvailablity;
	private String classType;
	Flight(){
		
	}
	public Flight(String flightNo, String depLoc, String arrLoc, Date validTill, String flightTime, String flighDur,
			String fare, String seatAvailablity, String classType) {
		super();
		//this.id=id;
		this.flightNo = flightNo;
		this.depLoc = depLoc;
		this.arrLoc = arrLoc;
		this.validTill = validTill;
		this.flightTime = flightTime;
		this.flighDur = flighDur;
		this.fare = fare;
		this.seatAvailablity = seatAvailablity;
		this.classType = classType;
	}
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getDepLoc() {
		return depLoc;
	}
	public void setDepLoc(String depLoc) {
		this.depLoc = depLoc;
	}
	public String getArrLoc() {
		return arrLoc;
	}
	public void setArrLoc(String arrLoc) {
		this.arrLoc = arrLoc;
	}
	public Date getValidTill() {
		return validTill;
	}
	public void setValidTill(Date validTill) {
		this.validTill = validTill;
	}
	public String getFlightTime() {
		return flightTime;
	}
	public void setFlightTime(String flightTime) {
		this.flightTime = flightTime;
	}
	public String getFlightDur() {
		return flighDur;
	}
	public void setFlightDur(String flighDur) {
		this.flighDur = flighDur;
	}
	public String getFare() {
		return fare;
	}
	public void setFare(String fare) {
		this.fare = fare;
	}
	public String getSeatAvailability() {
		return seatAvailablity;
	}
	public void setSeatAvailablity(String seatAvailablity) {
		this.seatAvailablity = seatAvailablity;
	}
	public String getClassType() {
		return classType;
	}
	public void setClassType(String classType) {
		this.classType = classType;
	}
}
