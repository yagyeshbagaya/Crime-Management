package com.nagarro.flightdetails;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import com.opencsv.*;
import java.io.*;
import java.text.SimpleDateFormat;
public class DAO {
	final static String absolutePath = "D:\\Eclipse\\Assignment-2\\src\\main\\resources\\data";
	List<Flight> flights = Collections.synchronizedList(new ArrayList<Flight>());
	List<String> fileNames = Collections.synchronizedList(new ArrayList<String>());
	StandardServiceRegistry ssr;
	Metadata meta ;   
	SessionFactory factory ;  
	Session session ;
	Transaction t;
	public DAO() {
		super();
		populateInfo();
	}

	public List<Flight> getFlights(String depLoc, String arrLoc, Date flightDate, String classType,
			String outputPreference) 
	{
		Comparator<Flight> compare = Comparator.comparing(Flight::getFare);
		if (outputPreference.equalsIgnoreCase("both")) {
			compare = compare.thenComparing(Flight::getFlightDur);
		}
		Criteria  c=session.createCriteria(Flight.class);//passing Class class argument  
	    	    Criterion c1 = Restrictions.eq("depLoc", depLoc);
	    	    Criterion c2 = Restrictions.eq("arrLoc", arrLoc);
	    	    Criterion c3 = Restrictions.eq("classType", classType); 
	    	    Criterion c4 = Restrictions.and(c1,c2,c3);
	    	    c.add(c4);
	    	    List <Flight> list=c.list();  
	    	    Iterator <Flight> i=list.iterator();
	    	    while (i.hasNext()) {
	    			Flight f = i.next();
	    			System.out.println(f.getFlightNo() + "    " + f.getDepLoc() + "     " + f.getArrLoc() + "    "
	    					+ new SimpleDateFormat("dd-MMM-yyyy").format(f.getValidTill()) + "    "
	    					+ f.getFlightTime().substring(0, 2) + ":" + f.getFlightTime().substring(2) + "        "
	    					+ f.getFlightDur() + "     " + f.getFare() + "    " + f.getClassType());
	    		}
	      factory.close();  
          session.close();         
		List<Flight> result = new LinkedList<>();
		result = list.stream().sorted(compare).collect(Collectors.toList());
		return result;
	}

	public void readFilesName(final File folder, String absolutePath) {
		ExecutorService es = Executors.newCachedThreadPool();
		for (final File fileEntry : folder.listFiles()) {
			Runnable r = () -> {
				if (fileEntry.isDirectory()) {
					readFilesName(fileEntry, absolutePath + File.separator + fileEntry.getName());
				} else {
					if (fileEntry.getName().contains(".csv")) {
						fileNames.add(absolutePath + File.separator + fileEntry.getName());
					}
				}
			};
			es.execute(r);
		}
		es.shutdown();
		try {
			es.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
	
	public void getContent() {
		ExecutorService es = Executors.newCachedThreadPool();
        ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
     meta = new MetadataSources(ssr).getMetadataBuilder().build();   
	 factory = meta.getSessionFactoryBuilder().build();  
	 session = factory.openSession();  
	for (String s :fileNames) {
			Runnable r = () -> {
				try {
					FileReader fr = new FileReader(s);
					CSVParser parser = new CSVParserBuilder().withSeparator('|').build();
					CSVReader csvReader = new CSVReaderBuilder(fr).withCSVParser(parser).withSkipLines(1).build();
					Flight flight;
					String[] line;
					while ((line = csvReader.readNext()) != null) {
						Date sdf = new SimpleDateFormat("dd-MM-yyyy").parse(line[3]);
						flight = new Flight(line[0], line[1], line[2], sdf, line[4], line[5], line[6],
								line[7], line[8]);
			flights.add(flight);
						
				}
		
			
					csvReader.close();
					fr.close();
										
				} catch (Exception e) {
					e.printStackTrace();
				}
			
			};
			
			  			es.execute(r);		
		}
		es.shutdown();
		try {
			es.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println(e);
}
		
		Iterator <Flight> i;
		i=flights.iterator();
		Flight f;
		while(i.hasNext())
		{	
			f=i.next();
		    t = session.beginTransaction();
			session.save(f); 
			
			 session.flush();
		      session.clear();
		      t.commit(); 
		   // System.out.println("successfully saved");  
			System.out.println(f.getFlightNo() + "    " + f.getDepLoc() + "     " + f.getArrLoc() + "    "
				+ new SimpleDateFormat("dd-MMM-yyyy").format(f.getValidTill()) + "    "
					+ f.getFlightTime().substring(0, 2) + ":" + f.getFlightTime().substring(2) + "        "
					+ f.getFlightDur() + "     " + f.getFare() + "    " + f.getClassType());

		}
		//factory.close();  
	    //session.close();
	    System.out.println(flights.size());
		}
	public void populateInfo() {
		final File folder = new File("D:\\Eclipse\\Assignment-2\\src\\main\\resources\\data");
		readFilesName(folder, absolutePath);
		getContent();
	}
	
	
	
}
