package assignment;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;
import com.opencsv.*;
import java.text.SimpleDateFormat;
public class FlightInfo {
	final static String absolutePath = "D:\\Eclipse\\Assignment_5\\src\\main\\resources\\data";
	List<Flight> flights = Collections.synchronizedList(new ArrayList<Flight>());
	List<String> fileNames = Collections.synchronizedList(new ArrayList<String>());

	public FlightInfo() {
		super();
		populateInfo();
	}

	public List<Flight> getFlights(String depLoc, String arrLoc, Date flightDate, String classType,
			String outputPreference) {
		List<Flight> result = new LinkedList<>();
		Comparator<Flight> compare = Comparator.comparing(Flight::getFare);
		if (outputPreference.equalsIgnoreCase("both")) {
			compare = compare.thenComparing(Flight::getFlightDur);
		}
		result = flights.stream()
				.filter(f -> flightDate.compareTo(f.getValidTill()) <= 0
						&& f.getSeatAvailability().equalsIgnoreCase("Y") && f.getDepLoc().equalsIgnoreCase(depLoc)
						&& f.getArrLoc().equalsIgnoreCase(arrLoc)
						&& (f.getClassType().equalsIgnoreCase("EB") || f.getClassType().equalsIgnoreCase(classType)))
				.sorted(compare).collect(Collectors.toList());
		return result;
	}

	public void readFilesName(final File folder, String absolutePath) {
		ExecutorService es = Executors.newCachedThreadPool();
		for (final File fileEntry : folder.listFiles()) {
			Runnable r = () -> {
				if (fileEntry.isDirectory()) {
					readFilesName(fileEntry, absolutePath + File.separator + fileEntry.getName());
				} else {
					if (fileEntry.getName().contains(".csv")) {
						fileNames.add(absolutePath + File.separator + fileEntry.getName());
					}
				}
			};
			es.execute(r);
		}
		es.shutdown();
		try {
			es.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}

	public void getContent() {
		ExecutorService es = Executors.newCachedThreadPool();
		for (String s : fileNames) {
			Runnable r = () -> {
				try {
					FileReader fr = new FileReader(s);
					CSVParser parser = new CSVParserBuilder().withSeparator('|').build();
					CSVReader csvReader = new CSVReaderBuilder(fr).withCSVParser(parser).withSkipLines(1).build();
					Flight flight;
					String[] line;
					while ((line = csvReader.readNext()) != null) {
						SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
						flight = new Flight(line[0], line[1], line[2], sdf.parse(line[3]), line[4], line[5], line[6],
								line[7], line[8]);
						flights.add(flight);
					}
					csvReader.close();
					fr.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			};
			es.execute(r);
		}
		es.shutdown();
		try {
			es.awaitTermination(1, TimeUnit.MINUTES);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
	public void populateInfo() {
		final File folder = new File("D:\\Eclipse\\Assignment_5\\src\\main\\resources\\data");
		readFilesName(folder, absolutePath);
		getContent();
	}
}
